<?php
// Database connection settings
$servername = "localhost";
$username = "root";  // Change if necessary
$password = "";      // Your MySQL password (if any)
$dbname = "grade_management";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected successfully!<br>";  // Debugging connection
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $studentId = $_POST['studentId'];
    $course = $_POST['course'];
    $attendanceDate = $_POST['attendence_date']; // Ensure this matches the form
    $status = $_POST['status'];

    // Prepare SQL to insert attendance record
    $stmt = $conn->prepare("INSERT INTO attendence (student_id, course, attendence_date, status) VALUES (?, ?, ?, ?)");
    
    if ($stmt) {
        // Bind the parameters
        $stmt->bind_param("ssss", $studentId, $course, $attendence_date, $status);

        // Execute the query
        if ($stmt->execute()) {
            echo "Attendance recorded successfully!<br>";
        } else {
            echo "Error executing query: " . $stmt->error;  // Debugging output
        }

        // Close statement
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;  // Debugging output
    }

    // Redirect back to form after submission
    header("Location: Attendence.php");
    exit();
}

// Fetch attendance records (moved outside of form handling)
$sql = "SELECT student_id, course, attendence_date, status FROM attendence";  // Ensure table name is correct
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Management</title>
    <link rel="stylesheet" href="Attendence.css"> <!-- Add your custom CSS here -->
</head>
<body>
    <div class="container">
        <h2>Attendance Management</h2>

        <!-- Attendance Form -->
        <form action="Attendence.php" method="POST">
            <h3>Mark Attendance</h3>
            <label for="studentId">Student ID:</label>
            <input type="text" id="studentId" name="studentId" placeholder="Enter Student ID" required>

            <label for="course">Course:</label>
            <input type="text" id="course" name="course" placeholder="Enter Course Name" required>

            <label for="attendence_date">Attendance Date:</label>
            <input type="date" id="attendence_date" name="attendence_date" required>

            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="Present">Present</option>
                <option value="Absent">Absent</option>
            </select>

            <input type="submit" value="Mark Attendance">
        </form>

        <!-- Display Attendance Records -->
        <h3>Attendance Records</h3>
        <table border="1">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Course</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result) {
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>{$row['student_id']}</td>
                                    <td>{$row['course']}</td>
                                    <td>{$row['attendence_date']}</td>
                                    <td>{$row['status']}</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No attendance records found.</td></tr>";
                    }
                } else {
                    echo "Error fetching records: " . $conn->error; 
                }

                // Close connection
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
