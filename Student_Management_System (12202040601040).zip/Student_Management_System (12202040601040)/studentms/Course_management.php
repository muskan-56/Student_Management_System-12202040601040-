<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course and Class Management</title>
    <link rel="stylesheet" href="Course_management.css">
</head>
<body>
    <div class="container">
        <h2>Course and Class Management</h2>
        
        <form id="course-form" onsubmit="addCourse(event)">
            <h3>Add New Course</h3>
            <label for="courseName">Course Name:</label>
            <input type="text" id="courseName" name="courseName" placeholder="Enter Course Name" required>

            <label for="courseCode">Course Code:</label>
            <input type="text" id="courseCode" name="courseCode" placeholder="Enter Course Code" required>

            <label for="courseDuration">Duration (in weeks):</label>
            <input type="number" id="courseDuration" name="courseDuration" placeholder="Enter Duration" required>

            <label for="courseInstructor">Instructor Name:</label>
            <input type="text" id="courseInstructor" name="courseInstructor" placeholder="Enter Instructor Name" required>

            <input type="submit" value="Add Course">
        </form>

        <h3>Manage Courses</h3>
        <table id="coursesTable">
            <thead>
                <tr>
                    <th>Course Name</th>
                    <th>Course Code</th>
                    <th>Duration (weeks)</th>
                    <th>Instructor</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

        <form id="class-form" onsubmit="addClass(event)">
            <h3>Add New Class</h3>
            <label for="classCourse">Select Course:</label>
            <select id="classCourse" name="classCourse" required>
                <option value="" disabled selected>Select Course</option>
            </select>

            <label for="classDate">Class Date:</label>
            <input type="date" id="classDate" name="classDate" required>

            <label for="classTime">Class Time:</label>
            <input type="time" id="classTime" name="classTime" required>

            <input type="submit" value="Add Class">
        </form>

        <h3>Manage Classes</h3>
        <table id="classesTable">
            <thead>
                <tr>
                    <th>Course Name</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>

    <script src="course.js"></script>
</body>
</html>
