document.getElementById("grade-form").addEventListener("submit", function (e) {
    const studentId = document.getElementById("studentId").value.trim();
    const course = document.getElementById("course").value.trim();
    const examDate = document.getElementById("examDate").value.trim();
    const grade = document.getElementById("grade").value.trim();

    if (!studentId || !course || !examDate || !grade) {
        e.preventDefault(); // Prevents form submission
        alert("All fields are required!");
    }
});
