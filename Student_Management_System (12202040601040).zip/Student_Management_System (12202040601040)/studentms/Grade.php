<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grade and Examination Management</title>
    <link rel="stylesheet" href="grade.css">
</head>
<body>
    <div class="container">
        <h2>Grade and Examination Management</h2>

        <!-- Form to add a new grade -->
        <form id="grade-form" action="Grade_add.php" method="POST" class="form-section">
            <h3>Add New Grade</h3>
            <label for="studentId">Student ID:</label>
            <input type="text" id="studentId" name="studentId" placeholder="Enter Student ID" required>

            <label for="course">Course:</label>
            <input type="text" id="course" name="course" placeholder="Enter Course Name" required>

            <label for="examDate">Exam Date:</label>
            <input type="date" id="examDate" name="examDate" required>

            <label for="grade">Grade:</label>
            <input type="text" id="grade" name="grade" placeholder="Enter Grade" required>

            <input type="submit" value="Add Grade" class="btn">
        </form>

        <!-- Table to display the list of grades -->
        <h3>Grade Records</h3>
        <table id="gradeTable">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Course</th>
                    <th>Exam Date</th>
                    <th>Grade</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Database connection
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "grade_management";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch grade records from the database
                $stmt = $conn->prepare("SELECT student_id, course, exam_date, grade FROM grades");
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>" . htmlspecialchars($row['student_id']) . "</td>
                                <td>" . htmlspecialchars($row['course']) . "</td>
                                <td>" . htmlspecialchars($row['exam_date']) . "</td>
                                <td>" . htmlspecialchars($row['grade']) . "</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No records found</td></tr>";
                }

                $stmt->close();
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>

    <script src="Grade.js"></script>
</body>
</html>
