<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Your existing code below
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "grade_management";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentId = $_POST['studentId'] ?? '';
    $course = $_POST['course'] ?? '';
    $examDate = $_POST['examDate'] ?? '';
    $grade = $_POST['grade'] ?? '';

    if (empty($studentId) || empty($course) || empty($examDate) || empty($grade)) {
        die("All fields are required!");
    }

    $stmt = $conn->prepare("INSERT INTO grades (student_id, course, exam_date, grade) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $studentId, $course, $examDate, $grade);

    if ($stmt->execute()) {
        echo "Grade added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
