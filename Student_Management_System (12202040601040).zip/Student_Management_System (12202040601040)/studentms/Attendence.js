// Attendance.js

// Auto-fill today's date in the attendanceDate field
document.addEventListener("DOMContentLoaded", function() {
    const dateInput = document.getElementById("attendanceDate");
    const today = new Date().toISOString().substr(0, 10);
    dateInput.value = today;
});

// Confirm before submitting attendance
const form = document.getElementById("grade-form");
form.addEventListener("submit", function(event) {
    const confirmSubmit = confirm("Are you sure you want to mark this attendance?");
    if (!confirmSubmit) {
        event.preventDefault();
    }
});

// Live search functionality to filter the attendance records
document.addEventListener("DOMContentLoaded", function() {
    const searchInput = document.createElement("input");
    searchInput.placeholder = "Search by Student ID or Course";
    searchInput.style.padding = "10px";
    searchInput.style.marginBottom = "20px";
    document.querySelector(".container").insertBefore(searchInput, document.querySelector("table"));

    searchInput.addEventListener("input", function() {
        const filter = searchInput.value.toLowerCase();
        const rows = document.querySelectorAll("tbody tr");
        
        rows.forEach(row => {
            const studentId = row.querySelector("td:nth-child(1)").innerText.toLowerCase();
            const course = row.querySelector("td:nth-child(2)").innerText.toLowerCase();
            if (studentId.includes(filter) || course.includes(filter)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
});
